package ramirez.sebastianezequielrecuperatorio1p321;

public class ErrorHallazgoRepetidoException extends RuntimeException{
    private final static String MENSAJE = "Hallazgo en fecha y lugar ya registrado";

    public ErrorHallazgoRepetidoException() {
        super(MENSAJE);
    }

    public ErrorHallazgoRepetidoException(String mensaje) {
        super(mensaje);
    }
}
