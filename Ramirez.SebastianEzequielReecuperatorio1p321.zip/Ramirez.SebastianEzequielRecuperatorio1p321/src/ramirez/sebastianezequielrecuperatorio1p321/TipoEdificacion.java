package ramirez.sebastianezequielrecuperatorio1p321;

public enum TipoEdificacion {
    TEMPLO,
    VIVIENDA
}
