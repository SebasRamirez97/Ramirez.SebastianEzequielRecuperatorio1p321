package ramirez.sebastianezequielrecuperatorio1p321;

public enum TipoEpoca {
    PRECOLONIAL,
    COLONIAL,
    MODERNA
}
