
package ramirez.sebastianezequielrecuperatorio1p321;

public interface Analizable {
    public void analizar();
}
