package ramirez.sebastianezequielrecuperatorio1p321;

import java.time.LocalDate;

public class Construccion extends Hallazgo implements Restaurable{
    private TipoEdificacion edificacion;
    private TipoEpoca epoca;

    public Construccion(String lugarDescubrimiento, LocalDate fechaDescubrimiento, int estadoConservacion, TipoEdificacion edificacion, TipoEpoca epoca) {
        super(lugarDescubrimiento, fechaDescubrimiento, estadoConservacion);
        this.edificacion = edificacion;
        this.epoca = epoca;
    }
    
    @Override
    public void restaurar() {
        System.out.println("Restaurando edificio");
    }
    public boolean esDeEpoca(TipoEpoca epoca) {
        return epoca.ordinal() == epoca.ordinal();
    }

    @Override
    public String toString() {
        return super.toString()+"Construcciones{" + "edificacion=" + edificacion + ", epoca=" + epoca + '}';
    }

    
    
    
}
