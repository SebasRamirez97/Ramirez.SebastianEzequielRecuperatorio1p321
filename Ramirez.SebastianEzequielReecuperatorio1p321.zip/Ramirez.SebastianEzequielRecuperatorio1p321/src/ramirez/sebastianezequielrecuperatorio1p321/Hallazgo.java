package ramirez.sebastianezequielrecuperatorio1p321;

import java.time.LocalDate;
import java.util.Objects;

public class Hallazgo {
    private String lugarDescubrimiento;
    private LocalDate fechaDescubrimiento;
    private final static int ESTADO_MIN_RAN = 0;
    private final static int ESTADO_MAX_RAN = 10;
    private int estadoConservacion;
    private int hallazgoID; 
    private static int INICIAL_ID = 50000;

    public Hallazgo(String lugarDescubrimiento, LocalDate fechaDescubrimiento, int estadoConservacion) {
        this.lugarDescubrimiento = lugarDescubrimiento;
        this.fechaDescubrimiento = fechaDescubrimiento;
        verificarEstado(estadoConservacion);
        this.hallazgoID = INICIAL_ID++;
    }
    
    
    
    private void verificarEstado(int estado) {
        if (estado < ESTADO_MIN_RAN || estado > ESTADO_MAX_RAN) {
            throw new ErrorEstadoException();
        }
    }

    public int getEstadoConservacion() {
        return estadoConservacion;
    }
    
    public boolean esAnalizable() {
        return this instanceof Analizable;
    }
    
    @Override
    public boolean equals(Object o) {
        if (o == null || !(o instanceof Hallazgo especie)) {
            return false;
        }

        return lugarDescubrimiento.equals(especie.lugarDescubrimiento) && fechaDescubrimiento.equals(especie.fechaDescubrimiento);
    }
    
    

    @Override
    public int hashCode() {
        return Objects.hash(lugarDescubrimiento, fechaDescubrimiento);
    }

    @Override
    public String toString() {
        return "Hallazgo{" + "lugarDescubrimiento=" + lugarDescubrimiento + ", fechaDescubrimiento=" + fechaDescubrimiento + ", estadoConservacion=" + estadoConservacion + ", hallazgoID=" + hallazgoID + '}';
    }
    
    
    
}


