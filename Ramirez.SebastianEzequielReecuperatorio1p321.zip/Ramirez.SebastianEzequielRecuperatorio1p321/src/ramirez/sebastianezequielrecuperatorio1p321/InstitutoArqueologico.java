package ramirez.sebastianezequielrecuperatorio1p321;

import java.util.ArrayList;
import java.util.List;

public class InstitutoArqueologico {

    private List<Hallazgo> hallazgos;

    public InstitutoArqueologico() {
        this.hallazgos = new ArrayList<>();
    }

    private boolean hallazgoRepetido(Hallazgo hallazgo) {
        return hallazgos.contains(hallazgo);
    }

    public void registrarHallazgo(Hallazgo hallazgo) {
        if (hallazgoRepetido(hallazgo)) {
            throw new ErrorEstadoException();
        }
        hallazgos.add(hallazgo);
    }

    private void mostrarListaHallazgos(List<Hallazgo> listaHallazgos) {
        if (listaHallazgos.isEmpty()) {
            System.out.println("Lista de especies vacia");
        } else {
            int i = 0;
            while (i < listaHallazgos.size()) {
                System.out.println(listaHallazgos.get(i));
                i++;
            }
        }
    }

    public void mostrarHallazgos() {
        mostrarListaHallazgos(hallazgos);
    }

    public void ejecutarAnalisisDeLaboratorio() {
        for (Hallazgo h : hallazgos) {
            if (h.esAnalizable()) {
                ((Analizable) h).analizar();
            }
        }

    }

    public void realizarTareasDeRestauracion() {
        for (Hallazgo h : hallazgos) {
            if (!h.esAnalizable()) {
                ((Restaurable) h).restaurar();
            }
        }
    }

    public void filtrarPorEpoca(TipoEpoca epocaBuscada) {
        List<Construccion> hallazgosDeEpoca = new ArrayList<>();
        for (Hallazgo h : hallazgos) {
            if (h instanceof Construccion construccion) {
                if (((Construccion) h).esDeEpoca(epocaBuscada)) {
                    hallazgosDeEpoca.add(construccion);
                }
            }
        }
        if (hallazgosDeEpoca.isEmpty()) {
            System.out.println("Lista de especies vacia");
        } else {
            int i = 0;
            while (i < hallazgosDeEpoca.size()) {
                System.out.println(hallazgosDeEpoca.get(i));
                i++;
            }
        }
    }
    
    public void filtrarPorRangoEstadoConservacion(int min , int max){
        List<Hallazgo> filtroPorEstado = new ArrayList<>();
        for (Hallazgo h : hallazgos) {
            if(h.getEstadoConservacion()>= min && (h.getEstadoConservacion()<= max)){
                filtroPorEstado.add(h);
            
            }
        }
        mostrarListaHallazgos(filtroPorEstado);
    }

}
