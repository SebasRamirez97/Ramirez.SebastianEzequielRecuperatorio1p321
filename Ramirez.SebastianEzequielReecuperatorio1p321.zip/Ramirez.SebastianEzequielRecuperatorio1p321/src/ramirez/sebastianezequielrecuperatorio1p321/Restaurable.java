package ramirez.sebastianezequielrecuperatorio1p321;


public interface Restaurable {
    public void restaurar();
}
