package ramirez.sebastianezequielrecuperatorio1p321;

public class ErrorEstadoException extends RuntimeException {
     
    private final static String MENSAJE = "Valor de estado invalido";

    public ErrorEstadoException() {
        super(MENSAJE);
    }

    public ErrorEstadoException(String mensaje) {
        super(mensaje);
    }

}

