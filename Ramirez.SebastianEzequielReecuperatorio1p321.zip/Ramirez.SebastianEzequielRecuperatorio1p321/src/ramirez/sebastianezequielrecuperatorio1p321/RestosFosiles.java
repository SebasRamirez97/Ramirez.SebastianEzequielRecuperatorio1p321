package ramirez.sebastianezequielrecuperatorio1p321;

import java.time.LocalDate;

public class RestosFosiles extends Hallazgo implements Analizable{
    private String especieDescubierta;
    private boolean estaCompleta;

    public RestosFosiles(String lugarDescubrimiento, LocalDate fechaDescubrimiento, int estadoConservacion, String especieDescubierta, boolean estaCompleta) {
        super(lugarDescubrimiento, fechaDescubrimiento, estadoConservacion);
        this.especieDescubierta = especieDescubierta;
        this.estaCompleta = estaCompleta;
    }
    
    @Override
    public void analizar() {
        System.out.println("Analizando resto fosil");
    }
    
    @Override
    public String toString() {
        return super.toString()+"RestosFosiles{" + "especieDescubierta=" + especieDescubierta + ", estaCompleta=" + estaCompleta + '}';
    }

    
    
    
}

