package ramirez.sebastianezequielrecuperatorio1p321;

import java.time.LocalDate;

public class Herramientas extends Hallazgo implements Analizable{
    private String material;
    private String usoProbable;

    public Herramientas(String lugarDescubrimiento, LocalDate fechaDescubrimiento, int estadoConservacion, String material, String usoProbable) {
        super(lugarDescubrimiento, fechaDescubrimiento, estadoConservacion);
        this.material = material;
        this.usoProbable = usoProbable;
    }
    @Override
    public void analizar() {
        System.out.println("Analizando Herramienta");
    }
    
    @Override
    public String toString() {
        return super.toString()+"Herramientas{" + "material=" + material + ", usoProbable=" + usoProbable + '}';
    }

    
    
    
}
